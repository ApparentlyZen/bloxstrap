-- ============================================================
--  Bloxstrap v2.0 - Script Principal
--  UI: Rayfield | github.com/ApparentlyZen/Bloxstrap
-- ============================================================

local cloneref   = cloneref or function(...) return ... end
local Players    = cloneref(game:GetService("Players"))
local HttpSvc    = cloneref(game:GetService("HttpService"))
local UIS        = cloneref(game:GetService("UserInputService"))
local StarterGui = cloneref(game:GetService("StarterGui"))
local CoreGui    = cloneref(game:GetService("CoreGui"))

local lplr   = Players.LocalPlayer
local getgenv = getgenv or function() return _G end

-- ============================================================
--  GLOBAL
-- ============================================================
getgenv().Bloxstrap     = getgenv().Bloxstrap or {}
local BS                = getgenv().Bloxstrap
BS.Version              = "2.0"
BS.TouchEnabled         = UIS.TouchEnabled

-- ============================================================
--  FONCTIONS FFLAG
-- ============================================================
BS.ToggleFFlag = loadfile("Bloxstrap/Main/Functions/ToggleFFlag.lua")()
BS.GetFFlag    = loadfile("Bloxstrap/Main/Functions/GetFFlag.lua")()

-- ============================================================
--  UTILITAIRES
-- ============================================================
local function notify(title, text, duration)
	pcall(function()
		StarterGui:SetCore("SendNotification", {
			Title = title or "Bloxstrap",
			Text  = text  or "",
			Duration = duration or 5,
		})
	end)
end

local function isAlive(player)
	player = player or lplr
	local ok, res = pcall(function()
		return player.Character
			and player.Character.PrimaryPart
			and player.Character:FindFirstChild("Humanoid")
			and player.Character.Humanoid.Health > 0
	end)
	return ok and res or false
end

local function safeReadJson(path)
	local ok, data = pcall(function()
		return HttpSvc:JSONDecode(readfile(path))
	end)
	return (ok and type(data) == "table") and data or {}
end

-- ============================================================
--  CONFIG
-- ============================================================
local CONFIG_PATH = "Bloxstrap/Main/Configs/Default.json"

local DEFAULT_CONFIG = {
	FPS                  = 120,
	DisplayFPS           = false,
	AntiAliasingQuality  = "Automatique",
	LightingTechnology   = "Choix du jeu",
	TextureQuality       = "Automatique",
	DisablePlayerShadows = false,
	DisablePostFX        = false,
	DisableTerrainTex    = false,
	GraySky              = false,
	DeRendering          = false,
	GUIScale             = false,
	Crosshair            = false,
	CrosshairImage       = "",
	CameraSensitivity    = 1,
	FontChangerEnabled   = false,
	FontPreset           = "GothamSsm",
	CustomFont           = "",
	OofSound             = false,
	TouchUI              = false,
	TouchUISize          = 1.2,
}

local Config = {}
for k, v in DEFAULT_CONFIG do Config[k] = v end

if isfile(CONFIG_PATH) then
	local saved = safeReadJson(CONFIG_PATH)
	for k, v in saved do Config[k] = v end
end

local function saveConfig()
	pcall(function()
		writefile(CONFIG_PATH, HttpSvc:JSONEncode(Config))
	end)
end

local function set(key, value)
	Config[key] = value
	saveConfig()
end

-- ============================================================
--  RAYFIELD
-- ============================================================
local Rayfield = loadstring(game:HttpGet("https://sirius.menu/rayfield"))()

local Window = Rayfield:CreateWindow({
	Name            = "Bloxstrap  v" .. BS.Version,
	Icon            = "zap",
	LoadingTitle    = "Bloxstrap",
	LoadingSubtitle = "Chargement...",
	Theme           = "Default",
	DisableRayfieldPrompts  = true,
	DisableBuildWarnings    = true,
	ConfigurationSaving     = { Enabled = false },
	KeySystem               = false,
})

-- ============================================================
--  ONGLET ENGINE
-- ============================================================
local EngineTab = Window:CreateTab("Engine", "cpu")

EngineTab:CreateSection("Performance")

local origFPS = BS.GetFFlag("DFIntTaskSchedulerTargetFps")
EngineTab:CreateInput({
	Name            = "Limite FPS",
	CurrentValue    = tostring(Config.FPS),
	PlaceholderText = "ex: 120  |  0 = illimité",
	RemoveTextAfterFocusLost = false,
	Flag            = "FPSInput",
	Callback = function(val)
		local fps = tonumber(val)
		if not fps then return end
		set("FPS", fps)
		BS.ToggleFFlag("FFlagTaskSchedulerLimitTargetFpsTo2402", fps >= 70)
		if fps > 0 then
			pcall(setfpscap, fps)
			BS.ToggleFFlag("DFIntTaskSchedulerTargetFps", fps)
		else
			pcall(setfpscap, 9e9)
			BS.ToggleFFlag("DFIntTaskSchedulerTargetFps", origFPS)
		end
		notify("Bloxstrap", "FPS → " .. (fps > 0 and tostring(fps) or "∞"))
	end,
})

EngineTab:CreateToggle({
	Name         = "Afficher compteur FPS",
	CurrentValue = Config.DisplayFPS,
	Flag         = "DisplayFPS",
	Callback = function(v)
		set("DisplayFPS", v)
		BS.ToggleFFlag("FFlagDebugDisplayFPS", v)
	end,
})

EngineTab:CreateSection("Rendu")

EngineTab:CreateToggle({
	Name         = "Désactiver ombres joueurs",
	CurrentValue = Config.DisablePlayerShadows,
	Flag         = "DisableShadows",
	Callback = function(v)
		set("DisablePlayerShadows", v)
		BS.ToggleFFlag("FIntRenderShadowIntensity", v and 0 or 1)
	end,
})

EngineTab:CreateToggle({
	Name         = "Désactiver effets post-traitement",
	CurrentValue = Config.DisablePostFX,
	Flag         = "DisablePostFX",
	Callback = function(v)
		set("DisablePostFX", v)
		BS.ToggleFFlag("FFlagDisablePostFx", v)
	end,
})

EngineTab:CreateToggle({
	Name         = "Désactiver textures terrain",
	CurrentValue = Config.DisableTerrainTex,
	Flag         = "DisableTerrain",
	Callback = function(v)
		set("DisableTerrainTex", v)
		BS.ToggleFFlag("FIntTerrainArraySliceSize", v and 0 or 4)
	end,
})

EngineTab:CreateSection("Qualité")

EngineTab:CreateDropdown({
	Name          = "Anti-aliasing (MSAA)",
	Options       = {"Automatique", "1x", "2x", "4x"},
	CurrentOption = {Config.AntiAliasingQuality},
	Flag          = "MSAA",
	Callback = function(option)
		local val = type(option) == "table" and option[1] or option
		set("AntiAliasingQuality", val)
		BS.ToggleFFlag("FIntDebugForceMSAASamples",
			val == "Automatique" and -1 or tonumber(val:gsub("x","")) or -1)
	end,
})

EngineTab:CreateDropdown({
	Name          = "Qualité des textures",
	Options       = {"Automatique", "Très basse", "Basse", "Moyenne", "Haute", "Très haute"},
	CurrentOption = {Config.TextureQuality},
	Flag          = "TextureQuality",
	Callback = function(option)
		local val = type(option) == "table" and option[1] or option
		set("TextureQuality", val)
		local map = {
			["Automatique"] = {e=false, l=3, m=0},
			["Très basse"]  = {e=true,  l=0, m=2},
			["Basse"]       = {e=true,  l=0, m=0},
			["Moyenne"]     = {e=true,  l=1, m=0},
			["Haute"]       = {e=true,  l=2, m=0},
			["Très haute"]  = {e=true,  l=3, m=0},
		}
		local c = map[val] or map["Automatique"]
		BS.ToggleFFlag("DFFlagTextureQualityOverrideEnabled", c.e)
		BS.ToggleFFlag("DFIntTextureQualityOverride", c.l)
		BS.ToggleFFlag("FIntDebugTextureManagerSkipMips", c.m)
	end,
})

EngineTab:CreateDropdown({
	Name          = "Technologie d'éclairage",
	Options       = {"Choix du jeu", "Voxel (Phase 1)", "Shadow Map (Phase 2)", "Future (Phase 3)"},
	CurrentOption = {Config.LightingTechnology},
	Flag          = "Lighting",
	Callback = function(option)
		local val = type(option) == "table" and option[1] or option
		set("LightingTechnology", val)
		pcall(function()
			local tech = val:find("Voxel") and "Voxel"
				or val:find("Shadow") and "ShadowMap"
				or val:find("Future") and "Future" or nil
			if tech then sethiddenproperty(game.Lighting, "Technology", tech) end
			BS.ToggleFFlag("DFFlagDebugRenderForceTechnologyVoxel",      val:find("Voxel")  ~= nil)
			BS.ToggleFFlag("DFFlagDebugRenderForceFutureIsBrightPhase2", val:find("Shadow") ~= nil)
			BS.ToggleFFlag("DFFlagDebugRenderForceFutureIsBrightPhase3", val:find("Future") ~= nil)
		end)
	end,
})

-- ============================================================
--  ONGLET FAST FLAGS
-- ============================================================
local FFlagTab = Window:CreateTab("Fast Flags", "flag")

FFlagTab:CreateSection("Presets — Sans risque de ban")

FFlagTab:CreateToggle({
	Name         = "Ciel gris",
	CurrentValue = Config.GraySky,
	Flag         = "GraySky",
	Callback = function(v)
		set("GraySky", v)
		BS.ToggleFFlag("FFlagDebugSkyGray", v)
		notify("Bloxstrap", v and "Ciel gris activé (rejoin requis)" or "Ciel gris désactivé")
	end,
})

FFlagTab:CreateSection("Éditeur JSON")

local currentFFlagJson = "{}"
pcall(function() currentFFlagJson = readfile("Bloxstrap/FFlags.json") end)

FFlagTab:CreateInput({
	Name            = "Coller des Fast Flags (JSON)",
	CurrentValue    = currentFFlagJson,
	PlaceholderText = '{ "FFlagNom": "true" }',
	RemoveTextAfterFocusLost = false,
	Flag            = "FFlagEditor",
	Callback = function(text)
		local ok, data = pcall(function()
			return HttpSvc:JSONDecode(
				text:gsub('"True"',"true"):gsub('"False"',"false")
			)
		end)
		if not ok or type(data) ~= "table" then
			notify("Bloxstrap ✖", "JSON invalide !", 4)
			return
		end
		writefile("Bloxstrap/FFlags.json", HttpSvc:JSONEncode(data))
		local count = 0
		for flag, val in data do
			BS.ToggleFFlag(flag, val)
			count += 1
		end
		notify("Bloxstrap ✔", count .. " FFlag(s) appliquée(s)")
	end,
})

FFlagTab:CreateButton({
	Name = "Réinitialiser les FFlags",
	Callback = function()
		writefile("Bloxstrap/FFlags.json", "{}")
		notify("Bloxstrap", "FFlags réinitialisées (rejoin pour effet total)")
	end,
})

-- ============================================================
--  ONGLET APPARENCE
-- ============================================================
local AppTab = Window:CreateTab("Apparence", "paintbrush-2")

AppTab:CreateSection("Joueur")

local deRenderConn
AppTab:CreateToggle({
	Name         = "De-Rendering",
	CurrentValue = Config.DeRendering,
	Flag         = "DeRender",
	Callback = function(v)
		set("DeRendering", v)
		BS.ToggleFFlag("FFlagDisablePostFx", v)
		if v then
			task.spawn(function()
				repeat
					for _, player in Players:GetPlayers() do
						if not isAlive(lplr) then break end
						if player ~= lplr and isAlive(player) then
							local r1 = lplr.Character and lplr.Character:FindFirstChild("HumanoidRootPart")
							local r2 = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
							if r1 and r2 then
								local dist = (r1.Position - r2.Position).Magnitude
								for _, track in player.Character.Humanoid:GetPlayingAnimationTracks() do
									track:AdjustSpeed(dist <= 100 and 1 or 0)
								end
							end
						end
					end
					task.wait()
				until not Config.DeRendering
			end)
		end
	end,
})

pcall(function()
	local CamInput = require(lplr.PlayerScripts.PlayerModule.CameraModule.CameraInput)
	local origRot  = CamInput.getRotation
	AppTab:CreateSlider({
		Name         = "Sensibilité caméra",
		Range        = {1, 7},
		Increment    = 0.1,
		Suffix       = "x",
		CurrentValue = Config.CameraSensitivity,
		Flag         = "CamSens",
		Callback = function(val)
			set("CameraSensitivity", val)
			CamInput.getRotation = function(...)
				return origRot(...) * val
			end
		end,
	})
end)

AppTab:CreateSection("Interface")

local guiSets = {}
local guiConn
AppTab:CreateToggle({
	Name         = "Réduire l'interface Roblox",
	CurrentValue = Config.GUIScale,
	Flag         = "GUIScale",
	Callback = function(v)
		set("GUIScale", v)
		if v then
			local function applyScale(gui, isCore)
				if gui.Name == "TouchGui" then return end
				local existing = gui:FindFirstChildWhichIsA("UIScale", not isCore)
				if existing then
					table.insert(guiSets, {scaler=existing, old=existing.Scale})
					existing.Scale = isCore and (existing.Scale - 0.3) or 0.5
				else
					local s = Instance.new("UIScale", gui)
					s.Scale = 0.7
					table.insert(guiSets, {scaler=s, old=9e9})
				end
			end
			guiConn = lplr.PlayerGui.ChildAdded:Connect(function(c) applyScale(c, false) end)
			for _, c in lplr.PlayerGui:GetChildren() do applyScale(c, false) end
			for _, c in CoreGui:GetChildren()        do applyScale(c, true)  end
		else
			pcall(function() guiConn:Disconnect() end)
			for _, e in guiSets do
				if e.old == 9e9 then pcall(function() e.scaler:Destroy() end)
				else pcall(function() e.scaler.Scale = e.old end) end
			end
			table.clear(guiSets)
		end
	end,
})

-- Crosshair
local crosshairLabel
local crosshairGui = Instance.new("ScreenGui", CoreGui)
crosshairGui.IgnoreGuiInset = true
crosshairGui.ResetOnSpawn   = false

AppTab:CreateToggle({
	Name         = "Crosshair custom",
	CurrentValue = Config.Crosshair,
	Flag         = "Crosshair",
	Callback = function(v)
		set("Crosshair", v)
		if v then
			crosshairLabel = Instance.new("ImageLabel", crosshairGui)
			crosshairLabel.Size               = UDim2.new(0, 22, 0, 22)
			crosshairLabel.AnchorPoint        = Vector2.new(0.5, 0.5)
			crosshairLabel.Position           = UDim2.new(0.5, 0, 0.5, 0)
			crosshairLabel.BackgroundTransparency = 1
			crosshairLabel.Image = Config.CrosshairImage ~= "" and pcall(getcustomasset, Config.CrosshairImage) and getcustomasset(Config.CrosshairImage) or ""
			task.spawn(function()
				repeat
					task.wait()
					if crosshairLabel and isAlive() then
						local head = lplr.Character:FindFirstChild("Head")
						if head then
							crosshairLabel.Visible = (head.Position - workspace.CurrentCamera.CFrame.Position).Magnitude <= 3
						end
					end
				until not Config.Crosshair
			end)
		else
			if crosshairLabel then crosshairLabel:Destroy() crosshairLabel = nil end
		end
	end,
})

local crosshairImages = {"aucune"}
pcall(function()
	for _, f in listfiles("Bloxstrap/Images") do
		table.insert(crosshairImages, f)
	end
end)
AppTab:CreateDropdown({
	Name          = "Image crosshair",
	Options       = crosshairImages,
	CurrentOption = {Config.CrosshairImage ~= "" and Config.CrosshairImage or "aucune"},
	Flag          = "CrosshairImg",
	Callback = function(option)
		local val = type(option) == "table" and option[1] or option
		if val == "aucune" then val = "" end
		set("CrosshairImage", val)
		if crosshairLabel and val ~= "" then
			pcall(function() crosshairLabel.Image = getcustomasset(val) end)
		end
	end,
})

AppTab:CreateSection("Police")

local updatedFonts    = {}
local fontConn
local currentCustomFont = nil

local function applyFontTo(inst)
	if not (inst.ClassName == "TextLabel" or inst.ClassName == "TextButton" or inst.ClassName == "TextBox") then return end
	local original = tostring(inst.Font):split(".")[3] or "GothamSsm"
	local conn = inst:GetPropertyChangedSignal("Font"):Connect(function()
		pcall(function()
			if currentCustomFont then inst.FontFace = currentCustomFont
			else inst.Font = Enum.Font[Config.FontPreset] end
		end)
	end)
	table.insert(updatedFonts, {inst=inst, original=original, conn=conn})
	pcall(function()
		if currentCustomFont then inst.FontFace = currentCustomFont
		else inst.Font = Enum.Font[Config.FontPreset] end
	end)
end

local function enableFonts()
	fontConn = game.DescendantAdded:Connect(function(v) pcall(applyFontTo, v) end)
	for _, v in game:GetDescendants() do pcall(applyFontTo, v) end
end

local function disableFonts()
	pcall(function() fontConn:Disconnect() end)
	for _, e in updatedFonts do
		pcall(function()
			e.conn:Disconnect()
			e.inst.Font = Enum.Font[e.original]
		end)
	end
	table.clear(updatedFonts)
end

AppTab:CreateToggle({
	Name         = "Changer les polices du jeu",
	CurrentValue = Config.FontChangerEnabled,
	Flag         = "FontChanger",
	Callback = function(v)
		set("FontChangerEnabled", v)
		if v then enableFonts() else disableFonts() end
	end,
})

local fontList = {}
for _, v in Enum.Font:GetEnumItems() do
	table.insert(fontList, tostring(v):split(".")[3])
end
AppTab:CreateDropdown({
	Name          = "Police Roblox",
	Options       = fontList,
	CurrentOption = {Config.FontPreset},
	Flag          = "FontPreset",
	Callback = function(option)
		local val = type(option) == "table" and option[1] or option
		set("FontPreset", val)
		currentCustomFont = nil
		if Config.FontChangerEnabled then disableFonts() enableFonts() end
	end,
})

local customFontList = {"none"}
pcall(function()
	for _, f in listfiles("Bloxstrap/Main/Fonts") do
		if f:find(".ttf") then table.insert(customFontList, f) end
	end
end)
AppTab:CreateDropdown({
	Name          = "Police custom (.ttf)",
	Options       = customFontList,
	CurrentOption = {Config.CustomFont ~= "" and Config.CustomFont or "none"},
	Flag          = "CustomFont",
	Callback = function(option)
		local val = type(option) == "table" and option[1] or option
		if val == "none" then
			currentCustomFont = nil
			set("CustomFont", "")
		else
			set("CustomFont", val)
			local jsonPath = val:gsub(".ttf", ".json")
			writefile(jsonPath, HttpSvc:JSONEncode({
				name  = "font",
				faces = {{name="Regular", weight=600, style="normal", assetId=getcustomasset(val)}}
			}))
			currentCustomFont = Font.new(getcustomasset(jsonPath), Enum.FontWeight.Regular)
		end
		if Config.FontChangerEnabled then disableFonts() enableFonts() end
	end,
})

-- ============================================================
--  ONGLET AUDIO
-- ============================================================
local AudioTab = Window:CreateTab("Audio", "volume-2")

AudioTab:CreateSection("Son de mort")

local deathConn
local function setupDeathSound()
	if deathConn then deathConn:Disconnect() deathConn = nil end
	repeat task.wait() until lplr.Character and lplr.Character:FindFirstChild("Humanoid")
	local hum = lplr.Character.Humanoid
	deathConn = hum.HealthChanged:Connect(function()
		if hum.Health <= 0 then
			pcall(function()
				lplr.PlayerScripts.RbxCharacterSounds.Enabled = false
				local soundId = isfile("Bloxstrap/deathsound.mp3") and getcustomasset("Bloxstrap/deathsound.mp3")
					or isfile("Bloxstrap/oofsound.mp3") and getcustomasset("Bloxstrap/oofsound.mp3") or nil
				if not soundId then return end
				local s = Instance.new("Sound", workspace)
				s.SoundId      = soundId
				s.Volume       = 0.5
				s.PlayOnRemove = true
				s:Destroy()
			end)
		end
	end)
end

lplr.CharacterAdded:Connect(function()
	pcall(function() lplr.PlayerScripts.RbxCharacterSounds.Enabled = true end)
	if Config.OofSound then task.spawn(setupDeathSound) end
end)

AudioTab:CreateToggle({
	Name         = isfile("Bloxstrap/deathsound.mp3") and "Son de mort custom" or "Ancien son de mort (oof)",
	CurrentValue = Config.OofSound,
	Flag         = "OofSound",
	Callback = function(v)
		set("OofSound", v)
		if v then task.spawn(setupDeathSound)
		else if deathConn then deathConn:Disconnect() deathConn = nil end end
	end,
})

AudioTab:CreateLabel("Place 'oofsound.mp3' ou 'deathsound.mp3' dans Bloxstrap/")

-- ============================================================
--  ONGLET MOBILE (uniquement si tactile)
-- ============================================================
if UIS.TouchEnabled then
	local MobileTab = Window:CreateTab("Mobile", "smartphone")

	MobileTab:CreateSection("Interface tactile")

	local touchScale
	MobileTab:CreateToggle({
		Name         = "Agrandir l'interface tactile",
		CurrentValue = Config.TouchUI,
		Flag         = "TouchUI",
		Callback = function(v)
			set("TouchUI", v)
			if v then
				pcall(function()
					touchScale = Instance.new("UIScale", lplr.PlayerGui.TouchGui)
					touchScale.Scale = Config.TouchUISize
				end)
			else
				if touchScale then touchScale:Destroy() touchScale = nil end
			end
		end,
	})

	MobileTab:CreateSlider({
		Name         = "Taille interface",
		Range        = {1, 2},
		Increment    = 0.05,
		Suffix       = "x",
		CurrentValue = Config.TouchUISize,
		Flag         = "TouchSize",
		Callback = function(val)
			set("TouchUISize", val)
			if touchScale then touchScale.Scale = val end
		end,
	})
end

-- ============================================================
--  ONGLET INFOS
-- ============================================================
local InfoTab = Window:CreateTab("Infos", "info")

InfoTab:CreateSection("À propos")
InfoTab:CreateLabel("Bloxstrap v" .. BS.Version .. " — github.com/ApparentlyZen/Bloxstrap")
InfoTab:CreateLabel("Config : Bloxstrap/Main/Configs/Default.json")
InfoTab:CreateLabel("FFlags actives : Bloxstrap/FFlags.json")

InfoTab:CreateSection("Actions")

InfoTab:CreateButton({
	Name = "💾  Sauvegarder la config",
	Callback = function()
		saveConfig()
		notify("Bloxstrap ✔", "Configuration sauvegardée !")
	end,
})

InfoTab:CreateButton({
	Name = "🗑  Réinitialiser la config",
	Callback = function()
		for k, v in DEFAULT_CONFIG do Config[k] = v end
		saveConfig()
		notify("Bloxstrap", "Config réinitialisée — relance le script pour appliquer")
	end,
})

InfoTab:CreateButton({
	Name = "🔄  Réinitialiser les FFlags",
	Callback = function()
		writefile("Bloxstrap/FFlags.json", "{}")
		notify("Bloxstrap", "FFlags réinitialisées — rejoin pour effet total")
	end,
})

-- ============================================================
--  APPLICATION AU DÉMARRAGE
-- ============================================================
task.spawn(function()
	task.wait(1)

	if Config.FPS and Config.FPS > 0 then
		pcall(setfpscap, Config.FPS)
		BS.ToggleFFlag("DFIntTaskSchedulerTargetFps", Config.FPS)
		BS.ToggleFFlag("FFlagTaskSchedulerLimitTargetFpsTo2402", Config.FPS >= 70)
	end
	if Config.DisablePlayerShadows then BS.ToggleFFlag("FIntRenderShadowIntensity", 0) end
	if Config.DisablePostFX        then BS.ToggleFFlag("FFlagDisablePostFx", true) end
	if Config.DisableTerrainTex    then BS.ToggleFFlag("FIntTerrainArraySliceSize", 0) end
	if Config.GraySky              then BS.ToggleFFlag("FFlagDebugSkyGray", true) end
	if Config.DisplayFPS           then BS.ToggleFFlag("FFlagDebugDisplayFPS", true) end

	local savedFlags = safeReadJson("Bloxstrap/FFlags.json")
	for flag, val in savedFlags do
		pcall(BS.ToggleFFlag, flag, val)
	end

	if Config.FontChangerEnabled then enableFonts() end
	if Config.OofSound           then task.spawn(setupDeathSound) end

	notify("Bloxstrap ✔", "Chargé avec succès ! v" .. BS.Version, 4)
end)

BS.Notify     = notify
BS.SaveConfig = saveConfig
BS.Config     = Config
return BS
