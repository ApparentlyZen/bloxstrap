-- ToggleFFlag.lua
local cloneref = cloneref or function(...) return ... end
local HttpService = cloneref(game:GetService("HttpService"))

return function(flag: string, value: any): ()
	if type(flag) ~= "string" then
		return task.spawn(error, "[Bloxstrap] ToggleFFlag: string attendu, reçu " .. type(flag))
	end

	local FFlag: string = (getgenv().Bloxstrap and getgenv().Bloxstrap.TouchEnabled)
		and flag
			:gsub("DFInt",""):gsub("DFFlag",""):gsub("FFlag","")
			:gsub("FInt",""):gsub("DFString",""):gsub("FString","")
		or flag

	if getfflag(FFlag) == nil then
		local logPath = getgenv().errorlog or "Bloxstrap/Logs/errors.txt"
		local existing = ""
		pcall(function() existing = readfile(logPath) end)
		pcall(function() writefile(logPath, existing .. "\n[" .. os.date() .. "] FFlag introuvable: " .. FFlag) end)
		return
	end

	local ok, data = pcall(function()
		return HttpService:JSONDecode(readfile("Bloxstrap/FFlags.json"))
	end)
	local fflagData = (ok and type(data) == "table") and data or {}
	fflagData[flag] = tostring(value)
	writefile("Bloxstrap/FFlags.json", HttpService:JSONEncode(fflagData))
	setfflag(FFlag, tostring(value))
end
