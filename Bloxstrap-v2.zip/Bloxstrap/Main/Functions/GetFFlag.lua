-- GetFFlag.lua
return function(flag: string): any
	if type(flag) ~= "string" then
		return task.spawn(error, "[Bloxstrap] GetFFlag: string attendu, reçu " .. type(flag))
	end

	local FFlag: string = (getgenv().Bloxstrap and getgenv().Bloxstrap.TouchEnabled)
		and flag
			:gsub("DFInt",""):gsub("DFFlag",""):gsub("FFlag","")
			:gsub("FInt",""):gsub("DFString",""):gsub("FString","")
		or flag

	if getfflag(FFlag) ~= nil then
		return getfflag(FFlag)
	end
	return nil
end
