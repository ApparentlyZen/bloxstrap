# Bloxstrap v2.0
**github.com/ApparentlyZen/Bloxstrap**

---

## Installation

1. Upload tous ces fichiers sur ton GitHub en gardant la structure des dossiers
2. Exécute `Initiate.lua` dans ton executor — tout se télécharge automatiquement

---

## Structure

```
Bloxstrap/
├── Initiate.lua                   ← À exécuter dans l'executor
├── Main/
│   ├── Bloxstrap.lua              ← Script principal
│   └── Functions/
│       ├── GetFFlag.lua
│       └── ToggleFFlag.lua
├── Main/Configs/Default.json      ← Config auto-sauvegardée
├── Main/Fonts/                    ← Tes polices custom (.ttf)
├── Images/                        ← Tes crosshairs (.png)
├── FFlags.json                    ← FFlags actives
└── oofsound.mp3                   ← Son de mort (optionnel)
```

---

## Features

**Engine** — FPS limiter, compteur FPS, ombres, PostFX, textures terrain, qualité textures, anti-aliasing, éclairage

**Fast Flags** — Ciel gris, éditeur JSON pour appliquer n'importe quelle FFlag, reset

**Apparence** — De-rendering, sensibilité caméra, GUI scaler, crosshair custom, changeur de police (Roblox + .ttf)

**Audio** — Ancien son de mort (oof) ou son custom

**Mobile** — Agrandissement interface tactile *(affiché uniquement sur mobile)*

---

## Ajouter un crosshair
Dépose ton `.png` dans `Bloxstrap/Images/` puis sélectionne-le dans le dropdown

## Ajouter une police custom
Dépose ton `.ttf` dans `Bloxstrap/Main/Fonts/` puis sélectionne-la dans le dropdown

## Son de mort custom
Dépose `deathsound.mp3` dans `Bloxstrap/` — il sera utilisé à la place du oof
