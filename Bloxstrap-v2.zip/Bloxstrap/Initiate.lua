-- ============================================================
--  Bloxstrap v2.0 — Point d'entrée
--  Exécute CE fichier dans ton executor
-- ============================================================

local cloneref = cloneref or function(...) return ... end
local HttpSvc  = cloneref(game:GetService("HttpService"))
local getasync = function(url) return game:HttpGet(url, true) end

-- Création des dossiers
for _, folder in {
	"Bloxstrap",
	"Bloxstrap/Main",
	"Bloxstrap/Main/Functions",
	"Bloxstrap/Main/Configs",
	"Bloxstrap/Main/Fonts",
	"Bloxstrap/Images",
	"Bloxstrap/Logs",
} do
	pcall(makefolder, folder)
end

if not isfile("Bloxstrap/FFlags.json") then
	writefile("Bloxstrap/FFlags.json", "{}")
end

-- ============================================================
local REPO_RAW = "https://raw.githubusercontent.com/ApparentlyZen/Bloxstrap/main/"

local FILES = {
	"Main/Bloxstrap.lua",
	"Main/Functions/GetFFlag.lua",
	"Main/Functions/ToggleFFlag.lua",
}

local function install()
	print("[Bloxstrap] Installation en cours...")
	for _, path in FILES do
		local ok, content = pcall(getasync, REPO_RAW .. path)
		if ok and content then
			writefile("Bloxstrap/" .. path, content)
			print("[Bloxstrap] ✔ " .. path)
		else
			warn("[Bloxstrap] ✖ Échec : " .. path)
		end
	end
	for _, asset in {"oofsound.mp3"} do
		local ok, content = pcall(getasync, REPO_RAW .. asset)
		if ok and content then writefile("Bloxstrap/" .. asset, content) end
	end
	print("[Bloxstrap] Installation terminée !")
end

local needsInstall = not isfile("Bloxstrap/Main/Bloxstrap.lua")
	or not isfile("Bloxstrap/Main/Functions/ToggleFFlag.lua")
	or not isfile("Bloxstrap/Main/Functions/GetFFlag.lua")

if needsInstall then install() end

local ok, err = pcall(function()
	loadfile("Bloxstrap/Main/Bloxstrap.lua")()
end)

if not ok then
	warn("[Bloxstrap] Erreur : " .. tostring(err))
	warn("[Bloxstrap] Tentative de réinstallation...")
	install()
	loadfile("Bloxstrap/Main/Bloxstrap.lua")()
end
